package org.example;

public class Circulo {

    private double raio;
    private double perimetro;
    private double diametro;

    public Circulo(double raio, double perimetro, double diametro) {
        this.raio = raio;
        this.perimetro = perimetro;
        this.diametro = diametro;
    }

    public static final double pi = 3.14159;

    public double calcularPerimetroPeloRaio() {
        if (raio == 0){
            throw new IllegalArgumentException("O raio não pode estar zerado.");
        }
        return perimetro = ((2 * pi) * raio);
    }

    public double calcularPerimetroPeloDiametro(){
        if (diametro == 0){
            throw new IllegalArgumentException("O diametro não pode estar zerado.");
        }
        return perimetro = (pi * diametro);
    }

    public double calcularRaioPeloPerimetro(){
        if (perimetro == 0){
            throw new IllegalArgumentException("O perimetro não pode estar zerado.");
        }
        return raio = (perimetro/(2 * pi));
    }

    public double calcularDiametroPeloPerimetro(){
        if (perimetro == 0){
            throw new IllegalArgumentException("O perimetro não pode estar zerado.");
        }
        return diametro = (perimetro / pi);
    }

    public double getRaio() {
        return raio;
    }

    public double getPerimetro() {
        return perimetro;
    }

    public double getDiametro() {
        return diametro;
    }
}
