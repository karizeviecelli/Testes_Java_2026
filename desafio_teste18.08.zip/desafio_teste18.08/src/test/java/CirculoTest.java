import org.example.Circulo;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;

import static junit.framework.TestCase.assertEquals;
import static org.junit.jupiter.api.Assertions.assertAll;

public class CirculoTest {

    @Test
    public void calcularPerimetroDeveCalcularDuasVezesPiVezesRaio(){

        // Arrange
        Circulo circulo = new Circulo(5,0,0);
        // Act
        double perimetro = circulo.calcularPerimetroPeloRaio();
        // Assert
        assertEquals(31.4159, perimetro,0.001);

    }

    @Test
    public void calcularPerimetroDeveCalcularPiVezesDiametro(){

        // Arrange
        Circulo circulo = new Circulo(0,0,10);
        // Act
        double perimetro = circulo.calcularPerimetroPeloDiametro();
        // Assert
        assertEquals(31.4159, perimetro,0.001);
    }

    @Test
    public void calcularRaioPeloPerimetroLancarExcecao(){

        Circulo circulo = new Circulo(0,0,0);

        Assertions.assertThrows(IllegalArgumentException.class, () -> circulo.calcularRaioPeloPerimetro());
    }

    @Test
    public void verificarSeRaioValido() {
        Circulo circulo = new Circulo(5, 0, 0);

        // O teste passa se a condição dentro do parêntese for VERDADEIRA
        Assertions.assertTrue(circulo.getRaio() > 0);
    }

    @Test
    public void calcularDiametroPeloPerimetroLancarExcecao(){

        Circulo circulo = new Circulo(0,0,0);

        Assertions.assertThrows(IllegalArgumentException.class, () -> circulo.calcularDiametroPeloPerimetro());
    }

    @Test
    public void construtorDeveInicializarTodosOsAtributos() {
        // ARRANGE + ACT
        Circulo circulo = new Circulo(5, 31.4159,10);

        // ASSERT: todas as verificações serão executadas.
        assertAll("Dados iniciais da conta", () -> Assertions.assertEquals(5, circulo.getRaio()), () -> Assertions.assertEquals(31.4159, circulo.getPerimetro()), () -> Assertions.assertEquals(10, circulo.getDiametro(), 0.001));
    }

}
